# Grimaldi Network — Holding Sites: Deploy & DNS Runbook

Two self-contained static sites (one `index.html` each, zero build step, zero
dependencies), in the exact AWS-style design system of igrimaldi.engineering:
dark utility bar cross-linking the network, sticky white nav, gradient hero with
floating card, white rounded sheet, three cards, warm notify banner, dark footer.
Four languages (EN/ES/DE/ZH) with the same `vg-locale` persistence key as the
portfolio. Every "Notify me" and "Connect" action is a pre-filled email — nothing
dead-ends.

- `engineeringgrimaldi.com/` — hardware & electrical engineering surface (violet-copper hero)
- `grimaldi.ca/` — personal blog surface (warm sunset hero)

## 1 — Create the repos and push (run in Codespaces or anywhere with git + gh)

```bash
# engineeringgrimaldi.com
cd engineeringgrimaldi.com
git init -b main && git add . && git commit -m "feat: holding site — hardware & EE surface"
gh repo create iceccarelli/engineeringgrimaldi.com --public --source=. --push

# grimaldi.ca
cd ../grimaldi.ca
git init -b main && git add . && git commit -m "feat: holding site — personal surface"
gh repo create iceccarelli/grimaldi.ca --public --source=. --push
```

(No `gh`? Create the two empty repos in the GitHub UI, then
`git remote add origin … && git push -u origin main`.)

## 2 — Deploy on Vercel

Vercel dashboard → Add New Project → import each repo. Framework preset:
**Other** (it's plain static — Vercel serves `index.html` as-is). Deploy.
Or from the CLI:

```bash
npm i -g vercel
cd engineeringgrimaldi.com && vercel --prod
cd ../grimaldi.ca && vercel --prod
```

## 3 — Attach the domains

Vercel → each project → Settings → Domains:
- Project 1: add `engineeringgrimaldi.com` + `www.engineeringgrimaldi.com` (www → apex redirect)
- Project 2: add `grimaldi.ca` + `www.grimaldi.ca`

## 4 — DNS at Porkbun (both domains, identical records)

Porkbun → domain → DNS. Delete conflicting A/ALIAS/CNAME records on `@` and `www`, then:

```
A      @     76.76.21.21
CNAME  www   cname.vercel-dns.com
```

Porkbun's SSL can stay — Vercel issues its own certificate once DNS resolves
(minutes to a few hours). Verify:

```bash
dig +short engineeringgrimaldi.com     # → 76.76.21.21
dig +short grimaldi.ca                 # → 76.76.21.21
curl -sI https://engineeringgrimaldi.com | head -3
curl -sI https://grimaldi.ca | head -3
```

## 5 — When the real sites are ready

Each holding site is a normal repo — the real site simply replaces `index.html`
(or grows into a framework project) and pushes to `main`. The domain, DNS, and
the links from igrimaldi.engineering never change. That is the point: the
network's URLs are permanent; only the content behind them evolves.
