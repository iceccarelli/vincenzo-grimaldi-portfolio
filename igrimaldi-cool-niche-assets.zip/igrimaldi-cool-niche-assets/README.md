# igrimaldi.engineering — Cool, Niche-Dominating Visual Assets
## Additional 10 images for vincenzo-grimaldi-portfolio (igrimaldi.engineering)

These 10 images are designed to be **visually striking, memorable, and immediately recognizable** as deep electrical engineering work.

They enhance the main target of the site: grids, machines, devices, and physics-informed methods. They make the site feel premium and credible in the niche so that engineers, operators, researchers, and technical buyers want to stop and look.

**Upload location recommendation:**  
`/public/images/cool/` or `/public/images/visual/` in the vincenzo-grimaldi-portfolio repo.

All images are landscape (approx. 1176×784), cinematic and technical.

---

### Why these help dominate the niche

- Instant visual recognition of high-voltage infrastructure and electrical machines.  
- Clear signal of physics-informed and digital twin capability.  
- Strong traction power and professional context.  
- Premium aesthetic that separates the site from generic engineering portfolios.  
- Memorable enough to be shared or remembered.

---

### Image Inventory + Placement + Why It Works

| # | Filename | What It Shows | Alt Text (SEO) | Recommended Placement | Why It Helps |
|---|----------|---------------|----------------|-----------------------|--------------|
| 01 | `01-cinematic-high-voltage-substation.jpg` | Night substation | Cinematic high-voltage substation at night | Homepage hero | Immediate “this is grids” signal. High impact. |
| 02 | `02-electromagnetic-fields-machine.jpg` | EM fields | Electromagnetic fields around an electrical machine | Machines section or hero secondary | Beautiful and technical. Rare visual. |
| 03 | `03-precision-stator-detail.jpg` | Stator detail | Precision electrical machine stator with copper windings | Machines & devices section | Extreme detail. Signals real machine knowledge. |
| 04 | `04-live-grid-digital-twin.jpg` | Live digital twin | Live digital twin of a power grid with data flows | Physics-informed / digital twins section | Clear modern capability visual. |
| 05 | `05-physics-meets-hardware.jpg` | Physics + hardware | Physics equations and waveforms meeting substation hardware | Physics-informed section or article | Core method of the site made visible. |
| 06 | `06-cinematic-traction-power.jpg` | Traction power | Cinematic railway traction power and high-speed train | Traction power section | Strong professional and domain signal. |
| 07 | `07-grid-scale-power-electronics.jpg` | Power electronics | Grid-scale power electronics and converters | Devices section | Modern power electronics credibility. |
| 08 | `08-grid-frequency-inertia-living.jpg` | Frequency & inertia | Grid frequency and inertia as a living system | Technical article or inertia section | Elegant and distinctive. |
| 09 | `09-advanced-research-simulator.jpg` | Research simulator | Advanced research simulator with power system models | Research / thesis / simulator section | Shows real technical workspace. |
| 10 | `10-future-grids-and-machines.jpg` | Vision | Future-looking electrical grids and machines | Closing or vision section | Inspiring but still grounded. |

---

### Suggested Placement Strategy

- **Hero**: 01 (strongest first impression) or 06  
- **Secondary hero / banner**: 02 or 04  
- **Grids & traction**: 01, 04, 06  
- **Machines & devices**: 02, 03, 07  
- **Physics-informed / digital twins**: 04, 05, 08  
- **Research / simulator**: 09  
- **Closing / vision**: 10  

Use these as the high-impact visuals that make visitors immediately understand the site is serious about electrical grids, machines, and physics-informed methods.

---

### SEO / AEO Notes

- File names are descriptive and niche-aligned.  
- Surround with language about high-voltage grids, electrical machines, traction power, digital twins, and physics-informed methods.  
- These images are meant to be seen and remembered.  
- Pair with the earlier electrical and critical assets for a complete system.  
- Prefer these over any remaining generic or outdated visuals.

These 10 images are the cool, high-quality visuals that help the site stand out and dominate its niche.  
Upload into the public directory of the vincenzo-grimaldi-portfolio repository.
