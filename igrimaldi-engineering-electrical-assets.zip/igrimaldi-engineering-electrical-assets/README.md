# igrimaldi.engineering — Electrical Engineering Ambition Visual Assets

These 10 professional images support the reframed site focused on **electrical grids, machines, devices, and physics-informed methods**.

They replace any remaining Physical AI / palletizer / cluster visuals.

**Upload location recommendation:**  
`/public/images/electrical/` in the vincenzo-grimaldi-portfolio (igrimaldi.engineering) repo.

All images are landscape (approx. 1176×784), dark technical aesthetic, suitable for heroes, section headers, and article illustrations.

---

### Content Pillars

- Grids & traction power  
- Electrical machines & devices  
- Physics-informed modelling / digital twins for power systems  
- Research notes and thesis work (simulator)  
- Technical articles (grid inertia, IT/OT, AI is power-bound)

---

### Image Inventory + Placement + SEO/AEO

| # | Filename | Primary Use | Alt Text (SEO) | Recommended Placement | AEO / Content Notes |
|---|----------|-------------|----------------|-----------------------|---------------------|
| 01 | `01-high-voltage-substation.jpg` | Hero / grids | High-voltage electrical substation with transformers and transmission infrastructure at dusk | Homepage hero or Grids section | Strong opening visual for electrical ambition. |
| 02 | `02-railway-traction-power.jpg` | Traction power | Railway traction power system with catenary, substations and HV equipment | Traction power / professional context section | Directly supports DB InfraGO / HV digitisation background. |
| 03 | `03-electrical-machines-windings.jpg` | Machines | Close-up of electrical machine copper windings and stator | Electrical machines & devices pillar | High-detail technical credibility. |
| 04 | `04-physics-informed-digital-twin-grid.jpg` | Digital twins | Physics-informed digital twin of a power grid with substations and power flows | Physics-informed modelling section | Core visual for digital twins and modelling work. |
| 05 | `05-grid-inertia-frequency-stability.jpg` | Article visual | Grid inertia and frequency stability visualization with rotating machines and waveforms | Technical article: Grid inertia and the 50 Hz constraint | Ideal companion for existing or new explainers. |
| 06 | `06-it-ot-convergence-control-room.jpg` | IT/OT | IT/OT convergence control room with SCADA and power system monitoring | Technical article: IT/OT convergence in railway traction power | Supports professional day-job context. |
| 07 | `07-electrical-devices-power-electronics.jpg` | Devices | Modern electrical devices and power electronics including inverters and protection equipment | Electrical machines & devices section | Complements machine visuals with power electronics. |
| 08 | `08-thesis-simulator-workspace.jpg` | Research | Engineering workspace with power system simulator models and research notes | Research notes / thesis / simulator section | Perfect for adapting existing simulator content. |
| 09 | `09-high-voltage-transmission-corridor.jpg` | Wide grids | High-voltage transmission corridor stretching across landscape | Supporting grids visual or footer / about | Atmospheric, high-impact infrastructure shot. |
| 10 | `10-physics-informed-ai-power-systems.jpg` | Abstract / AI | Physics-informed AI merging neural networks with electrical circuit and power flow models | Physics-informed methods or “AI is power-bound” article | Ties technical depth to both companies without product claims. |

---

### Suggested Page Structure

1. **Hero**  
   Image: `01-high-voltage-substation.jpg` or `09-...`  
   Headline: Electrical grids, machines, and physics-informed methods.  
   Sub: Technical work on traction power, digital twins, and power system modelling.

2. **Pillars**  
   - Grids & traction → 01, 02, 09  
   - Machines & devices → 03, 07  
   - Physics-informed / digital twins → 04, 10  
   - Research & simulator → 08  
   - Articles → 05 (inertia), 06 (IT/OT), 10 (AI is power-bound)

3. **Operator / Professional Context**  
   Short bio linking to companies (engineeringgrimaldi.com) and day job.  
   Use 02 or 06 as supporting visual.

4. **Technical Register (optional, simplified)**  
   Keep lightweight JSON/register only for documenting real technical work and evidence. Drop status-board / cluster theatre.

---

### SEO / AEO Recommendations

- File names are descriptive and keyword-aligned.  
- Use the provided alt texts.  
- Surround images with pillar language (grids, traction power, electrical machines, physics-informed, digital twins).  
- Link operator section to the companies hub and product sites.  
- Prefer these images over any remaining palletizer or robotics visuals.  
- Open Graph: use 01 or 04 as primary social image.

---

### Kill List (do not reintroduce)

- Physical AI & Robotics cluster language  
- Palletizer as core product  
- Empty KPI boards / weekly CEO reports  
- Three-cluster operating system  
- Any implication that abandoned robotics work is still the focus

These assets support technical credibility for both companies and personal depth.  
Upload into the public directory of the igrimaldi.engineering repository.
